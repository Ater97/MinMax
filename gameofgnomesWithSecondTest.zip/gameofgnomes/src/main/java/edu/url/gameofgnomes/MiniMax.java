package edu.url.gameofgnomes;

public interface MiniMax {
    
    //dont do anything here...
    Tree getTree();
    boolean checkWin();
    void constructTree(int noOfGnomes);
}
